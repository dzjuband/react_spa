function Footer() {
    return (
        <div className="card">
            <div className="card-header">
                Footer 
            </div>
            <div className="card-body">
                <h5 className="card-title">This is the site footer</h5>
                <p className="card-text">Here we can write some information about our site</p>
            </div>
        </div>
    );
}

export default Footer;