
function About() {
    return (
        <div className="paddTOP">
            <div className="alert alert-dark " role="alert">
                This is block about. It is about difficult project in react.js
            </div>
        </div>

    );
}

export default About;