function Error() {
    return (
        <div className="alert alert-danger" role="alert">
            Error routnig, please rewrite
        </div>

    );
}

export default Error;